document.addEventListener("DOMContentLoaded", () => {
    const tasksKey = "tasks";
    const userKey = "user";
    const scheduleKey = "schedule";
    const stressKey = "stressLevel";
    let tasks = JSON.parse(localStorage.getItem(tasksKey)) || [];

    const $welcome = document.getElementById("welcome");
    const $taskList = document.getElementById("taskList");
    const $taskInput = document.getElementById("taskInput");
    const $taskTime = document.getElementById("taskTime");
    const $addBtn = document.getElementById("addBtn");
    const $generateBtn = document.getElementById("generateBtn");
    const $schedule = document.getElementById("schedule");
    const $taskForm = document.getElementById("taskForm");
    const $logoutBtn = document.getElementById("logoutBtn");
    const $progressText = document.getElementById("progressText");
    const $progressBarText = document.getElementById("progressBarText");
    const $stressLevel = document.getElementById("stressLevel");
    const $stressTip = document.getElementById("stressTip");
    const $breathStartBtn = document.getElementById("breathStartBtn");
    const $breathStopBtn = document.getElementById("breathStopBtn");
    const $breathPhaseText = document.getElementById("breathPhaseText");
    const $breathCountdownText = document.getElementById("breathCountdownText");
    const $breathOrb = document.getElementById("breathOrb");
    const $breathInstruction = document.getElementById("breathInstruction");
    const $moodHistoryInput = document.getElementById("moodHistoryInput");
    const $sleepHoursInput = document.getElementById("sleepHoursInput");
    const $calcStressBtn = document.getElementById("calcStressBtn");
    const $stressScoreOutput = document.getElementById("stressScoreOutput");
    const $weeklyReportBtn = document.getElementById("weeklyReportBtn");
    const $weeklyReportOutput = document.getElementById("weeklyReportOutput");

    $welcome.innerText = `Hello ${localStorage.getItem(userKey) || "User"} 💙`;
    $schedule.innerText = localStorage.getItem(scheduleKey) || "";

    let breathingSource = null;

    function getStressTip(level) {
        switch (level) {
            case "calm":
                return "You seem calm. Keep your pace steady and start with the most important task.";
            case "normal":
                return "Feeling okay. Try 30–60 seconds of stretching between tasks to stay fresh.";
            case "stressed":
                return "You look stressed. Suggestion: take a 10-minute walk, drink water, then do 2 minutes of deep breathing (inhale 4s, exhale 6s).";
            case "very_stressed":
                return "High stress detected. Suggestion: pause now—5-minute slow breathing, light stretches, and a short walk. Then do the smallest task first.";
            default:
                return "";
        }
    }

    function renderStressTip() {
        const level = $stressLevel.value;
        $stressTip.innerText = getStressTip(level);
        localStorage.setItem(stressKey, level);
    }

    const savedStress = localStorage.getItem(stressKey);
    if (savedStress) $stressLevel.value = savedStress;
    renderStressTip();

    function saveTasks() {
        localStorage.setItem(tasksKey, JSON.stringify(tasks));
    }

    function normalizeTasks() {
        tasks = (tasks || []).map(t => ({
            name: String(t?.name ?? "").trim(),
            time: String(t?.time ?? "").trim(),
            completed: Boolean(t?.completed)
        })).filter(t => t.name && t.time);
    }

    function renderProgress() {
        const total = tasks.length;
        const completed = tasks.reduce((acc, t) => acc + (t.completed ? 1 : 0), 0);
        $progressText.innerText = `✔ ${completed}/${total} tasks completed`;

        const blocks = 10;
        const filled = total === 0 ? 0 : Math.round((completed / total) * blocks);
        const bar = "█".repeat(filled) + "-".repeat(blocks - filled);
        $progressBarText.innerText = `[${bar}]`;
    }

    function parseMoodHistoryInput(raw) {
        if (!raw) return [];
        const parts = String(raw)
            .split(/[,\s]+/)
            .map(s => s.trim())
            .filter(Boolean);
        const values = parts
            .map(p => Number(p))
            .filter(n => Number.isFinite(n));
        // Clamp to 1..5 because the backend assumes 1-5 scale.
        return values.map(v => Math.min(5, Math.max(1, v)));
    }

    function stressLevelFromScore(score) {
        if (score <= 30) return "calm";
        if (score <= 50) return "normal";
        if (score <= 70) return "stressed";
        return "very_stressed";
    }

    function renderTasks() {
        // Use document fragments for efficient DOM updates
        $taskList.innerHTML = "";
        const fragment = document.createDocumentFragment();

        tasks.forEach((task, index) => {
            const div = document.createElement("div");
            div.className = "task-item";

            const left = document.createElement("div");
            left.style.display = "flex";
            left.style.alignItems = "center";
            left.style.gap = "8px";

            const checkbox = document.createElement("input");
            checkbox.type = "checkbox";
            checkbox.checked = Boolean(task.completed);
            checkbox.addEventListener("change", () => {
                tasks[index].completed = checkbox.checked;
                saveTasks();
                renderProgress();
            });

            const label = document.createElement("span");
            label.textContent = `${task.name} (${task.time}h)`;
            if (task.completed) label.style.textDecoration = "line-through";

            left.appendChild(checkbox);
            left.appendChild(label);

            const deleteBtn = document.createElement("span");
            deleteBtn.textContent = "❌";
            deleteBtn.style.color = "red";
            deleteBtn.style.cursor = "pointer";
            deleteBtn.addEventListener("click", () => deleteTask(index));

            div.appendChild(left);
            div.appendChild(deleteBtn);
            fragment.appendChild(div);
        });

        $taskList.appendChild(fragment);
        saveTasks();
        renderProgress();
    }

    function setBreathOrbPhase(phase, durationSec) {
        $breathOrb.classList.remove("inhale", "exhale");
        $breathOrb.classList.add(phase === "inhale" ? "inhale" : "exhale");
        const dur = Number(durationSec) > 0 ? Number(durationSec) : 1;
        $breathOrb.style.transitionDuration = `${dur}s`;
        $breathOrb.classList.remove("idle");
    }

    function resetBreathingUI() {
        if (breathingSource) breathingSource.close();
        breathingSource = null;

        $breathOrb.classList.remove("inhale", "exhale");
        $breathOrb.classList.add("idle");
        $breathOrb.style.transitionDuration = "0s";

        $breathPhaseText.innerText = "";
        $breathCountdownText.innerText = "";
        $breathInstruction.innerText = "";

        $breathStartBtn.style.display = "";
        $breathStopBtn.style.display = "none";
    }

    function getBreathingInstruction(phase) {
        if (phase === "inhale") return "Breathe in slowly through your nose.";
        return "Breathe out slowly through your mouth.";
    }

    function addTask(e) {
        e.preventDefault();
        const name = $taskInput.value.trim();
        const time = $taskTime.value.trim();

        if (!name || !time) {
            alert("Enter task and time");
            return;
        }

        tasks.push({ name, time });
        $taskInput.value = "";
        $taskTime.value = "";
        renderTasks();
    }

    function deleteTask(index) {
        tasks.splice(index, 1);
        renderTasks();
    }

    async function generateSchedule(e) {
        e.preventDefault();

        if (!tasks.length) {
            alert("Add tasks first!");
            return;
        }

        try {
            const res = await fetch("http://localhost:3000/generate", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ tasks })
            });
            const text = await res.text();
            $schedule.innerText = text;
            localStorage.setItem(scheduleKey, text);
        } catch (err) {
            console.error(err);
            alert("Error generating timetable");
        }
    }

    // Prevent page reload on form submit (including Enter key).
    $taskForm.addEventListener("submit", addTask);
    $generateBtn.addEventListener("click", generateSchedule);
    $logoutBtn.addEventListener("click", () => {
        resetBreathingUI();
        localStorage.removeItem(userKey);
        localStorage.removeItem(tasksKey);
        localStorage.removeItem(scheduleKey);
        localStorage.removeItem(stressKey);
        window.location.href = "login.html";
    });

    $stressLevel.addEventListener("change", renderStressTip);

    $calcStressBtn.addEventListener("click", async () => {
        const moodHistory = parseMoodHistoryInput($moodHistoryInput.value);
        const sleepHours = Number($sleepHoursInput.value);
        const completed = tasks.reduce((acc, t) => acc + (t.completed ? 1 : 0), 0);
        const total = tasks.length;
        const todayStr = new Date().toISOString().slice(0, 10);

        if (!moodHistory.length) {
            alert("Please enter mood history (1-5 numbers, comma separated).");
            return;
        }
        if (!Number.isFinite(sleepHours)) {
            alert("Please enter valid sleep hours.");
            return;
        }

        try {
            const res = await fetch("http://localhost:3000/stress/score", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    moodHistory,
                    sleepHours,
                    taskCompletion: { completed, total },
                    date: todayStr
                })
            });

            const text = await res.text();
            if (!res.ok) {
                $stressScoreOutput.innerText = text;
                return;
            }

            const data = JSON.parse(text);
            if (data?.error) {
                $stressScoreOutput.innerText = String(data.error);
                return;
            }
            const score = data.score;
            $stressScoreOutput.innerText =
                `Stress score: ${score}/100\n\n` +
                `Mood avg: ${data.moodAvg} (stress: ${data.moodStress})\n` +
                `Sleep: ${data.sleepHours}h (stress: ${data.sleepStress})\n` +
                `Task completion: ${data.completionRatio} (stress: ${data.completionStress})\n\n` +
                `Weights: mood 0.4, sleep 0.3, completion 0.3`;

            // Auto-update the stress selector + tip so user sees actionable guidance.
            const suggested = stressLevelFromScore(score);
            $stressLevel.value = suggested;
            renderStressTip();
        } catch (err) {
            console.error(err);
            alert("Error calculating stress score");
        }
    });

    $weeklyReportBtn.addEventListener("click", async () => {
        $weeklyReportOutput.innerText = "Generating...";
        const endDate = new Date().toISOString().slice(0, 10);

        try {
            const res = await fetch(
                `http://localhost:3000/stress/weekly-report?endDate=${encodeURIComponent(endDate)}`,
                { method: "GET" }
            );
            const text = await res.text();
            $weeklyReportOutput.innerText = text;
        } catch (err) {
            console.error(err);
            $weeklyReportOutput.innerText = "Error generating weekly report.";
        }
    });

    $breathStartBtn.addEventListener("click", () => {
        // Avoid multiple active streams.
        if (breathingSource) breathingSource.close();

        const level = $stressLevel.value || "normal";

        $breathPhaseText.innerText = "";
        $breathCountdownText.innerText = "";
        $breathInstruction.innerText = "";
        $breathStartBtn.style.display = "none";
        $breathStopBtn.style.display = "";

        breathingSource = new EventSource(
            `http://localhost:3000/breathing/stream?stressLevel=${encodeURIComponent(level)}`
        );

        breathingSource.addEventListener("started", (e) => {
            const data = JSON.parse(e.data || "{}");
            $breathInstruction.innerText = "Get comfortable. Follow the inhale/exhale timing.";
            // Ensure orb is in a stable state before phaseChange arrives.
            $breathOrb.classList.remove("inhale", "exhale");
            $breathOrb.classList.add("idle");
            $breathOrb.style.transitionDuration = "0s";
        });

        breathingSource.addEventListener("phaseChange", (e) => {
            const data = JSON.parse(e.data || "{}");
            const phase = data.phase;
            const durationSec = data.nextDurationSec;
            const cycle = data.cycle;

            $breathPhaseText.innerText = `${phase === "inhale" ? "Inhale" : "Exhale"} (${durationSec}s)`;
            $breathCountdownText.innerText = `Seconds left: ${durationSec}`;
            $breathInstruction.innerText = `${getBreathingInstruction(phase)} Cycle ${cycle}.`;
            setBreathOrbPhase(phase, durationSec);
        });

        breathingSource.addEventListener("tick", (e) => {
            const data = JSON.parse(e.data || "{}");
            const remainingSec = data.remainingSec;
            if (typeof remainingSec === "number") {
                $breathCountdownText.innerText = `Seconds left: ${remainingSec}`;
            }
        });

        breathingSource.addEventListener("done", () => {
            $breathInstruction.innerText = "Done! Great job.";
            $breathOrb.classList.remove("inhale", "exhale");
            $breathOrb.classList.add("idle");
            $breathStartBtn.style.display = "";
            $breathStopBtn.style.display = "none";
            if (breathingSource) breathingSource.close();
            breathingSource = null;
        });

        breathingSource.onerror = () => {
            // If connection fails, close and reset.
            resetBreathingUI();
            alert("Breathing timer stopped (server not reachable).");
        };
    });

    $breathStopBtn.addEventListener("click", () => {
        resetBreathingUI();
    });

    normalizeTasks();
    renderTasks();
});