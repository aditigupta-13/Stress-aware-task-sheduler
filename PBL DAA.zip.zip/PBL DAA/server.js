const express = require("express");
const fs = require("fs").promises;
const { execFile } = require("child_process");
const cors = require("cors");
const path = require("path");

const app = express();

app.use(cors());
app.use(express.json());

const usersFile = path.join(__dirname, "Backend", "users.txt");
const stressHistoryFile = path.join(__dirname, "Backend", "stress_history.txt");

async function loadUsers() {
    // File format: "<user> <pass>" per line.
    // If file doesn't exist yet, treat it as empty.
    let content = "";
    try {
        content = await fs.readFile(usersFile, "utf8");
    } catch (e) {
        if (e && e.code === "ENOENT") return new Map();
        throw e;
    }

    const users = new Map();
    for (const line of content.split(/\r?\n/)) {
        const trimmed = String(line).trim();
        if (!trimmed) continue;
        const parts = trimmed.split(/\s+/);
        if (parts.length < 2) continue;
        const user = parts[0];
        const pass = parts[1];
        users.set(user, pass);
    }
    return users;
}

async function appendUser(user, pass) {
    // Append to users.txt atomically-ish for this simple project.
    // (Assumes low concurrency.)
    await fs.appendFile(usersFile, `${user} ${pass}\n`, "utf8");
}

app.post("/register", async (req, res) => {
    try {
        const user = String(req.body?.user || "").trim();
        const pass = String(req.body?.pass || "").trim();

        if (!user || !pass) {
            return res.status(400).send("Missing user or pass");
        }

        const users = await loadUsers();
        if (users.has(user)) {
            return res.status(409).send("User already exists");
        }

        await appendUser(user, pass);
        return res.send("Register success");
    } catch (err) {
        console.error(err);
        return res.status(500).send("Server error");
    }
});

app.post("/login", async (req, res) => {
    try {
        const user = String(req.body?.user || "").trim();
        const pass = String(req.body?.pass || "").trim();

        if (!user || !pass) {
            return res.status(400).send("Missing user or pass");
        }

        const users = await loadUsers();
        const ok = users.get(user) === pass;
        if (!ok) return res.send("Invalid credentials");

        return res.send("Login success");
    } catch (err) {
        console.error(err);
        return res.status(500).send("Server error");
    }
});

app.get("/breathing/stream", (req, res) => {
    // Server-Sent Events (SSE) stream for inhale/exhale timer.
    const stressLevel = String(req.query.stressLevel || "normal");

    const configByStress = {
        calm: { inhaleSec: 4, exhaleSec: 4, cycles: 5 },
        normal: { inhaleSec: 4, exhaleSec: 5, cycles: 5 },
        stressed: { inhaleSec: 4, exhaleSec: 6, cycles: 5 },
        very_stressed: { inhaleSec: 4, exhaleSec: 7, cycles: 6 }
    };

    const cfg = configByStress[stressLevel] || configByStress.normal;
    const inhaleSec = Number(cfg.inhaleSec);
    const exhaleSec = Number(cfg.exhaleSec);
    const cycles = Number(cfg.cycles);

    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");
    res.flushHeaders();

    const send = (eventName, data) => {
        res.write(`event: ${eventName}\n`);
        res.write(`data: ${JSON.stringify(data)}\n\n`);
    };

    send("started", { inhaleSec, exhaleSec, cycles, stressLevel });

    // State machine: inhale/exhale alternating for `cycles` complete pairs.
    let cycle = 1;
    let phase = "inhale"; // "inhale" | "exhale"
    let phaseDurationSec = phase === "inhale" ? inhaleSec : exhaleSec;
    let phaseEndsAt = Date.now() + phaseDurationSec * 1000;
    let lastRemainingSec = null;
    let finished = false;

    // Use interval to keep both the timer and phase transitions accurate.
    const interval = setInterval(() => {
        if (finished) return;

        const now = Date.now();
        const remainingMs = Math.max(0, phaseEndsAt - now);
        const remainingSec = Math.ceil(remainingMs / 1000);

        if (remainingSec !== lastRemainingSec) {
            lastRemainingSec = remainingSec;
            send("tick", { phase, cycle, remainingSec });
        }

        if (remainingMs <= 0) {
            // Advance state.
            if (phase === "inhale") {
                phase = "exhale";
                phaseDurationSec = exhaleSec;
                phaseEndsAt = Date.now() + phaseDurationSec * 1000;
                send("phaseChange", { phase, cycle, nextDurationSec: phaseDurationSec });
            } else {
                // completed one cycle (inhale + exhale)
                if (cycle >= cycles) {
                    finished = true;
                    clearInterval(interval);
                    send("done", { completed: true });
                    res.end();
                    return;
                }
                cycle += 1;
                phase = "inhale";
                phaseDurationSec = inhaleSec;
                phaseEndsAt = Date.now() + phaseDurationSec * 1000;
                send("phaseChange", { phase, cycle, nextDurationSec: phaseDurationSec });
            }
        }
    }, 200);

    req.on("close", () => {
        finished = true;
        clearInterval(interval);
    });
});

app.post("/generate", async (req, res) => {
    try {
        const tasks = req.body.tasks || [];
        // Build request content more efficiently by mapping and joining
        const data = tasks.map(task => `${task.name} ${task.time}`).join("\n") + "\n";
        const requestFile = path.join(__dirname, "Backend", "request.txt");
        const responseFile = path.join(__dirname, "Backend", "response.txt");

        // Write request.txt asynchronously
        await fs.writeFile(requestFile, data, "utf8");

        // Run backend.exe directly with execFile and cwd
        execFile(
            path.join(__dirname, "Backend", "backend.exe"),
            [],
            { cwd: path.join(__dirname, "Backend") },
            async (err) => {
                if (err) {
                    console.error(err);
                    return res.status(500).send("Error generating timetable");
                }
                // Read response.txt asynchronously
                try {
                    const output = await fs.readFile(responseFile, "utf8");
                    res.send(output);
                } catch (fileErr) {
                    console.error(fileErr);
                    res.status(500).send("Error reading generated timetable");
                }
            }
        );
    } catch (error) {
        console.error(error);
        res.status(500).send("Server error");
    }
});

app.post("/stress/score", async (req, res) => {
    try {
        const moodHistoryRaw = Array.isArray(req.body?.moodHistory) ? req.body.moodHistory : [];
        const sleepHours = Number(req.body?.sleepHours);
        const taskCompletion = req.body?.taskCompletion || {};
        const completed = Number(taskCompletion.completed ?? 0);
        const total = Number(taskCompletion.total ?? 0);
        const todayStr = new Date().toISOString().slice(0, 10);
        const dateStr = String(req.body?.date || todayStr).trim();

        // Validate input enough to safely build request.txt.
        const moodHistory = moodHistoryRaw
            .map((x) => Number(x))
            .filter((x) => Number.isFinite(x));

        if (!moodHistory.length) return res.status(400).send("moodHistory is required (numbers)");
        if (!Number.isFinite(sleepHours) || sleepHours < 0 || sleepHours > 24) return res.status(400).send("sleepHours must be valid (0-24)");
        if (!Number.isFinite(total) || total < 0) return res.status(400).send("taskCompletion.total must be valid (>=0)");
        if (!Number.isFinite(completed) || completed < 0) return res.status(400).send("taskCompletion.completed must be valid (>=0)");

        const requestFile = path.join(__dirname, "Backend", "request.txt");
        const responseFile = path.join(__dirname, "Backend", "response.txt");

        // Request format for C++ stress mode:
        // MODE STRESS
        // MOODS <comma separated>
        // SLEEP <number>
        // COMPLETED <number>
        // TOTAL <number>
        const data =
            `MODE STRESS\n` +
            `MOODS ${moodHistory.join(",")}\n` +
            `SLEEP ${sleepHours}\n` +
            `COMPLETED ${completed}\n` +
            `TOTAL ${total}\n`;

        await fs.writeFile(requestFile, data, "utf8");

        execFile(
            path.join(__dirname, "Backend", "backend.exe"),
            [],
            { cwd: path.join(__dirname, "Backend") },
            async (err) => {
                if (err) {
                    console.error(err);
                    return res.status(500).send("Error calculating stress score");
                }
                try {
                    const output = await fs.readFile(responseFile, "utf8");
                    // Persist one stress record per date for weekly reporting.
                    try {
                        const parsed = JSON.parse(output);
                        if (!parsed?.error && typeof parsed?.score === "number") {
                            let existing = "";
                            try {
                                existing = await fs.readFile(stressHistoryFile, "utf8");
                            } catch (e) {
                                if (e && e.code !== "ENOENT") throw e;
                            }

                            const histLine =
                                `${dateStr}|${parsed.score}|${parsed.moodAvg}|${parsed.sleepHours}|${parsed.completionRatio}`.trim();

                            const lines = existing
                                .split(/\r?\n/)
                                .map(l => l.trim())
                                .filter(Boolean)
                                .filter(l => !l.startsWith(`${dateStr}|`));

                            lines.push(histLine);
                            await fs.writeFile(stressHistoryFile, lines.join("\n") + "\n", "utf8");
                        }
                    } catch (parseErr) {
                        // If output isn't valid JSON, just skip persistence.
                        console.warn("Stress history persistence skipped:", parseErr?.message || parseErr);
                    }

                    res.send(output);
                } catch (fileErr) {
                    console.error(fileErr);
                    res.status(500).send("Error reading stress score result");
                }
            }
        );
    } catch (err) {
        console.error(err);
        return res.status(500).send("Server error");
    }
});

app.get("/stress/weekly-report", async (req, res) => {
    try {
        const endDate = String(req.query?.endDate || new Date().toISOString().slice(0, 10)).trim();
        const requestFile = path.join(__dirname, "Backend", "request.txt");
        const responseFile = path.join(__dirname, "Backend", "response.txt");

        // Request format for C++ weekly mode:
        // MODE WEEKLY
        // END <YYYY-MM-DD>
        // COUNT 7
        const data =
            `MODE WEEKLY\n` +
            `END ${endDate}\n` +
            `COUNT 7\n`;

        await fs.writeFile(requestFile, data, "utf8");

        execFile(
            path.join(__dirname, "Backend", "backend.exe"),
            [],
            { cwd: path.join(__dirname, "Backend") },
            async (err) => {
                if (err) {
                    console.error(err);
                    return res.status(500).send("Error generating weekly report");
                }
                try {
                    const output = await fs.readFile(responseFile, "utf8");
                    res.send(output);
                } catch (fileErr) {
                    console.error(fileErr);
                    res.status(500).send("Error reading weekly report result");
                }
            }
        );
    } catch (error) {
        console.error(error);
        res.status(500).send("Server error");
    }
});

app.listen(3000, () => {
    console.log("Server running on http://localhost:3000");
});